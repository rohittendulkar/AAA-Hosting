create index IX_5B21CFC8 on AAA_Customer (groupId);
create index IX_E78B452 on AAA_Customer (uuid_);
create index IX_F32FC896 on AAA_Customer (uuid_, companyId);
create unique index IX_3E1D7C98 on AAA_Customer (uuid_, groupId);

create index IX_42E4DECD on AAA_Service (groupId);
create index IX_D74DC097 on AAA_Service (uuid_);
create index IX_29DCCF31 on AAA_Service (uuid_, companyId);
create unique index IX_DE016DF3 on AAA_Service (uuid_, groupId);

create index IX_7906EF48 on AAA_Services (groupId);
create index IX_7A1FB3D2 on AAA_Services (uuid_);
create index IX_B0561916 on AAA_Services (uuid_, companyId);
create unique index IX_D99DED18 on AAA_Services (uuid_, groupId);