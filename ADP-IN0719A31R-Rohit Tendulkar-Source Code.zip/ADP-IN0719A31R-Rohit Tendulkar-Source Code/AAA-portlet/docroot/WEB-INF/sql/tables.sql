create table AAA_Customer (
	uuid_ VARCHAR(75) null,
	customerId LONG not null primary key,
	companyId LONG,
	groupId LONG,
	userId LONG,
	createDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	description VARCHAR(75) null,
	email VARCHAR(75) null,
	phone INTEGER,
	start_date DATE null,
	serviceId LONG
);

create table AAA_Service (
	uuid_ VARCHAR(75) null,
	serviceId LONG not null primary key,
	companyId LONG,
	groupId LONG,
	userId LONG,
	createDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	description VARCHAR(75) null
);

create table AAA_Services (
	uuid_ VARCHAR(75) null,
	serviceId LONG not null primary key,
	companyId LONG,
	groupId LONG,
	userId LONG,
	createDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	description VARCHAR(75) null,
	price DOUBLE
);