package com.lithan.liferay;

import java.util.Calendar;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.lithan.liferay.model.Customer;
import com.lithan.liferay.service.CustomerLocalServiceUtil;

/**
 * Portlet implementation class CustomerPortlet
 */
public class CustomerPortlet extends MVCPortlet {
	 
	public void addCustomer(ActionRequest request,ActionResponse response) throws Exception{
	 _updateCustomer(request);

     sendRedirect(request, response);
 }
	
	public void deleteCustomer(ActionRequest request, ActionResponse response)throws Exception {

        long customerId = ParamUtil.getLong(request, "customerId");

        CustomerLocalServiceUtil.deleteCustomer(customerId);

        sendRedirect(request, response);
    }
	
	public void updateCustomer(ActionRequest request, ActionResponse response)throws Exception {

        _updateCustomer(request);

        sendRedirect(request, response);
    }
	
	private Customer _updateCustomer(ActionRequest request) throws PortalException, SystemException{
		long customerId = ParamUtil.getLong(request, "customerId");
		String name = ParamUtil.getString(request, "name");
        String description = ParamUtil.getString(request, "description");
        String email = ParamUtil.getString(request, "email");
        int phone = ParamUtil.getInteger(request, "phone");
        long serviceId = ParamUtil.getLong(request, "serviceId");
        
        int year = ParamUtil.getInteger(request, "start_dateYear");
        int month = ParamUtil.getInteger(request, "start_dateMonth");
        int day = ParamUtil.getInteger(request, "start_dateDay");
        int hour = ParamUtil.getInteger(request, "start_dateHour");
        int minute = ParamUtil.getInteger(request, "start_dateMinute");
        int amPm = ParamUtil.getInteger(request, "start_dateAmPm");

        if (amPm == Calendar.PM) {
            hour += 12;
        }
        
        ServiceContext serviceContext = ServiceContextFactory.getInstance(Customer.class.getName(),request);
        
        Customer customer = null;
        
        if (customerId <= 0) {
        	System.out.println("Customer Added");
            customer = CustomerLocalServiceUtil.addCustomer(serviceContext.getUserId(), serviceContext.getScopeGroupId(),name, description, email, phone, month, day, year, hour, minute, serviceId,serviceContext);
        }
        else {
        	System.out.println("Customer Updated");
            customer = CustomerLocalServiceUtil.getCustomer(customerId);

            customer = CustomerLocalServiceUtil.updateCustomer(serviceContext.getUserId(), customerId, name, description, email, phone, month,day, year, hour, minute, serviceId, serviceContext);
        }
        
        return customer;
	}

}
