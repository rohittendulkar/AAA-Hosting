package com.lithan.liferay.service.util;

public class WebKeys implements com.liferay.portal.kernel.util.WebKeys{

	public static final String SERVICES = "SERVICES";
	public static final String SERVICES_CUSTOMER = "SERVICES_CUSTOMER";
	
}
