package com.lithan.liferay.service.permission;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;
import com.lithan.liferay.model.Services;
import com.lithan.liferay.service.ServicesLocalServiceUtil;

public class ServicesPermission {
	
	public static void check(PermissionChecker permissionChecker,long servicesId, String actionId) throws PortalException,SystemException {

        if (!contains(permissionChecker, servicesId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,long servicesId, String actionId) throws PortalException,SystemException {

        Services services = ServicesLocalServiceUtil.getServices(servicesId);

        return permissionChecker.hasPermission(services.getGroupId(),Services.class.getName(), services.getServiceId(), actionId);
}

}
